package com.creativeoffice.motosp.Adapter

import android.content.Context
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.creativeoffice.motosp.Datalar.ModelDetaylariData
import com.creativeoffice.motosp.R
import kotlinx.android.synthetic.main.tek_model_list.view.*


class MarkaModelAdapter(val myContext: Context, val tumModeller: ArrayList<ModelDetaylariData>) : _root_ide_package_.androidx.recyclerview.widget.RecyclerView.Adapter<MarkaModelAdapter.MyViewHolder>() {


    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): MyViewHolder {
        var viewHolder = LayoutInflater.from(myContext).inflate(R.layout.tek_model_list, p0, false)

        return MyViewHolder(viewHolder, myContext)
    }

    override fun getItemCount(): Int {
        return tumModeller.size
    }

    override fun onBindViewHolder(p0: MyViewHolder, p1: Int) {

        p0.setData(tumModeller.get(p1), myContext)
    }

    inner class MyViewHolder(viewHolder: View?, myContext: Context) {
        var tumLayout = viewHolder as _root_ide_package_.androidx.cardview.widget.CardView
        var tvMarka = tumLayout.tvMarka
        var tvModel = tumLayout.tvModel

        fun setData(oAnkiModel: ModelDetaylariData, myContext: Context) {

            tvMarka.text = oAnkiModel.marka.toString()
            tvModel.text = oAnkiModel.model.toString()


        }

    }


}