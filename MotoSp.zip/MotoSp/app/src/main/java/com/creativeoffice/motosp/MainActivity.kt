package com.creativeoffice.motosp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.creativeoffice.motosp.Adapter.MarkaModelAdapter
import com.creativeoffice.motosp.Datalar.ModelDetaylariData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    lateinit var tumModeller: ArrayList<ModelDetaylariData>
    var myRef = FirebaseDatabase.getInstance().reference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        rvModelListesi.layoutManager =
            _root_ide_package_.androidx.recyclerview.widget.LinearLayoutManager(this, _root_ide_package_.androidx.recyclerview.widget.LinearLayoutManager.VERTICAL, false)
        rvModelListesi.adapter = MarkaModelAdapter(this, tumModeller)

        markaModelGetir()

    }

    private fun markaModelGetir() {
        myRef.child("Motorlar").child("Bmw").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onCancelled(p0: DatabaseError) {

            }

            override fun onDataChange(p0: DataSnapshot) {

                for (gelenVeriler in p0.children){
                    var modeller = gelenVeriler.getValue(ModelDetaylariData::class.java)!!
                    tumModeller.add(modeller)
                }

            }

        })
    }
}
